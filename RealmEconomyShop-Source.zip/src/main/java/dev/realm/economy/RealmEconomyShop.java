package dev.realm.economy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class RealmEconomyShop extends JavaPlugin implements Listener, CommandExecutor {
    private File playersFile;
    private YamlConfiguration playersData;
    private NamespacedKey menuKey;
    private final Map<UUID, Double> balances = new ConcurrentHashMap<UUID, Double>();
    private final Map<UUID, ShopView> views = new HashMap<UUID, ShopView>();
    private enum Screen { HOME, CATEGORY }
    private static final String HOME = "home";
    private static final String CAT = "category";

    @Override public void onEnable() {
        saveDefaultConfig();
        menuKey = new NamespacedKey(this, "realm_shop_menu");
        loadBalances();
        generatePriceEntries();
        Bukkit.getPluginManager().registerEvents(this, this);
        for (String cmd : Arrays.asList("shop","money","pay","eco")) getCommand(cmd).setExecutor(this);
        long period = Math.max(20L, getConfig().getLong("economy.save-interval-seconds", 60) * 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, new Runnable() {
            @Override public void run() { saveBalances(); }
        }, period, period);
        getLogger().info("RealmEconomyShop enabled. Materials available: " + Material.values().length);
    }

    @Override public void onDisable() { saveBalances(); }

    private void loadBalances() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        playersFile = new File(getDataFolder(), "players.yml");
        playersData = YamlConfiguration.loadConfiguration(playersFile);
        ConfigurationSection sec = playersData.getConfigurationSection("balances");
        if (sec != null) for (String id : sec.getKeys(false)) {
            try { double v = sec.getDouble(id); if (validMoney(v)) balances.put(UUID.fromString(id), v); }
            catch (Exception ignored) {}
        }
    }
    private synchronized void saveBalances() {
        if (playersData == null || playersFile == null) return;
        for (Map.Entry<UUID,Double> e : balances.entrySet()) playersData.set("balances." + e.getKey().toString(), e.getValue());
        try { playersData.save(playersFile); } catch (IOException e) { getLogger().severe("Could not save players.yml: " + e.getMessage()); }
    }
    private double balance(UUID id) {
        Double b = balances.get(id);
        if (b == null) { b = getConfig().getDouble("starting-balance", 100.0); if (!validMoney(b)) b = 0.0; balances.put(id, b); }
        return b;
    }
    private boolean validMoney(double v) { return !Double.isNaN(v) && !Double.isInfinite(v) && v >= 0 && v <= getConfig().getDouble("economy.max-transaction", 1.0E9); }
    private boolean setBalance(UUID id, double v) { if (!validMoney(v)) return false; balances.put(id, v); return true; }
    private String money(double d) { return String.format(Locale.US, "%.2f", d) + getConfig().getString("currency-symbol", "$"); }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private void msg(CommandSender s, String key) { s.sendMessage(color(getConfig().getString("messages.prefix", "&8[&aShop&8] ")) + color(getConfig().getString("messages." + key, "&cError"))); }
    private void msg(CommandSender s, String key, Map<String,String> replacements) {
        String m = getConfig().getString("messages.prefix", "&8[&aShop&8] ") + getConfig().getString("messages." + key, "&cError");
        for (Map.Entry<String,String> e : replacements.entrySet()) m = m.replace("{" + e.getKey() + "}", e.getValue());
        s.sendMessage(color(m));
    }

    private void generatePriceEntries() {
        ConfigurationSection prices = getConfig().getConfigurationSection("shop.prices");
        if (prices == null) prices = getConfig().createSection("shop.prices");
        boolean changed = false;
        for (Material mat : Material.values()) {
            String path = "shop.prices." + mat.name();
            if (getConfig().contains(path)) continue;
            ConfigurationSection sec = getConfig().createSection(path);
            sec.set("enabled", !isRestricted(mat));
            sec.set("category", categoryFor(mat).name());
            double buy = defaultBuy(mat), sell = Math.max(0.0, Math.floor(buy * 0.4 * 100.0) / 100.0);
            if (mat == Material.NETHER_STAR) {
                sec.set("enabled", getConfig().getBoolean("nether-star.enabled", true));
                buy = getConfig().getDouble("nether-star.buy-price", 50000.0);
                sell = getConfig().getDouble("nether-star.sell-price", 15000.0);
            }
            sec.set("buy", buy); sec.set("sell", sell); changed = true;
        }
        if (changed) saveConfig();
    }
    private double defaultBuy(Material m) {
        if (m == Material.NETHER_STAR) return 50000;
        String n = m.name();
        if (n.contains("DIAMOND") || n.contains("NETHERITE")) return 250;
        if (n.contains("EMERALD")) return 120;
        if (n.contains("GOLD")) return 35;
        if (n.contains("IRON")) return 22;
        if (n.contains("ANCIENT_DEBRIS")) return 500;
        if (n.contains("SPAWN_EGG")) return 100;
        if (n.contains("ELYTRA") || n.contains("TOTEM") || n.contains("SHULKER")) return 1000;
        if (n.endsWith("_SWORD") || n.endsWith("_PICKAXE") || n.endsWith("_AXE") || n.endsWith("_CHESTPLATE") || n.endsWith("_HELMET") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")) return 60;
        if (n.contains("AIR") || isRestricted(m)) return 0;
        return 10;
    }
    private boolean isRestricted(Material m) {
        List<String> list = getConfig().getStringList("shop.restricted-materials");
        return m == Material.AIR || !m.isItem() || list.contains(m.name()) || m.isLegacy();
    }
    private enum Category { BUILDING, STONE, WOOD, EARTH, DECOR, FARMING, FOOD, MOB, MATERIALS, REDSTONE, TOOLS, WEAPONS, ARMOR, POTIONS, NETHER, END, OCEAN, RARE, MISC }
    private Category categoryFor(Material m) {
        String n = m.name();
        if (n.contains("NETHER") || n.contains("CRIMSON") || n.contains("WARPED") || n.contains("BASALT") || n.contains("BLACKSTONE") || n.contains("GILDED_BLACKSTONE")) return Category.NETHER;
        if (n.contains("END_") || n.contains("ENDER") || n.contains("PURPUR") || n.contains("CHORUS")) return Category.END;
        if (n.contains("PRISMARINE") || n.contains("CORAL") || n.contains("KELP") || n.contains("SEAGRASS") || n.contains("TURTLE") || n.contains("NAUTILUS") || n.contains("TRIDENT") || n.contains("HEART_OF_THE_SEA") || n.contains("FISH") || n.contains("SPONGE")) return Category.OCEAN;
        if (n.contains("SWORD") || n.contains("BOW") || n.contains("CROSSBOW") || n.contains("ARROW") || n.contains("TRIDENT")) return Category.WEAPONS;
        if (n.contains("HELMET") || n.contains("CHESTPLATE") || n.contains("LEGGINGS") || n.contains("BOOTS") || n.equals("ELYTRA") || n.equals("SHIELD")) return Category.ARMOR;
        if (n.contains("PICKAXE") || n.contains("AXE") || n.contains("SHOVEL") || n.contains("HOE") || n.equals("SHEARS") || n.equals("FLINT_AND_STEEL") || n.equals("FISHING_ROD") || n.equals("COMPASS") || n.equals("CLOCK")) return Category.TOOLS;
        if (n.contains("POTION") || n.contains("TIPPED_ARROW") || n.contains("ENCHANTED_BOOK") || n.contains("EXPERIENCE") || n.contains("BLAZE_POWDER") || n.contains("GHAST_TEAR") || n.contains("DRAGON_BREATH") || n.contains("ENDER_EYE")) return Category.POTIONS;
        if (n.contains("REDSTONE") || n.contains("REPEATER") || n.contains("COMPARATOR") || n.contains("PISTON") || n.contains("OBSERVER") || n.contains("HOPPER") || n.contains("DISPENSER") || n.contains("DROPPER") || n.contains("DAYLIGHT") || n.contains("LEVER") || n.contains("BUTTON") || n.contains("PRESSURE_PLATE") || n.contains("TRIPWIRE") || n.contains("RAIL")) return Category.REDSTONE;
        if (n.contains("LOG") || n.contains("WOOD") || n.contains("PLANKS") || n.contains("STAIRS") && (n.contains("OAK") || n.contains("SPRUCE") || n.contains("BIRCH") || n.contains("JUNGLE") || n.contains("ACACIA") || n.contains("DARK_OAK") || n.contains("CRIMSON") || n.contains("WARPED")) || n.contains("FENCE") || n.contains("DOOR") || n.contains("TRAPDOOR") || n.contains("SIGN") || n.contains("BOAT") || n.contains("CHEST")) return Category.WOOD;
        if (n.contains("DIRT") || n.contains("SAND") || n.contains("GRAVEL") || n.contains("CLAY") || n.contains("MUD") || n.contains("SNOW") || n.contains("SOUL_SOIL") || n.contains("PODZOL") || n.contains("MYCELIUM")) return Category.EARTH;
        if (n.contains("STONE") || n.contains("ORE") || n.contains("COAL") || n.contains("IRON_INGOT") || n.contains("GOLD_INGOT") || n.contains("DIAMOND") || n.contains("EMERALD") || n.contains("LAPIS") || n.contains("QUARTZ") || n.contains("INGOT") || n.contains("NUGGET") || n.contains("RAW_")) return Category.STONE;
        if (n.contains("WHEAT") || n.contains("SEEDS") || n.contains("SAPLING") || n.contains("FLOWER") || n.contains("TULIP") || n.contains("ROSE") || n.contains("FERN") || n.contains("GRASS") || n.contains("LEAVES") || n.contains("VINE") || n.contains("CROP") || n.contains("POTATO") || n.contains("CARROT") || n.contains("BEETROOT") || n.contains("SUGAR_CANE") || n.contains("CACTUS") || n.contains("PUMPKIN") || n.contains("MELON") || n.contains("BAMBOO") || n.contains("MUSHROOM")) return Category.FARMING;
        if (n.contains("BEEF") || n.contains("PORK") || n.contains("CHICKEN") || n.contains("MUTTON") || n.contains("RABBIT") || n.contains("COD") || n.contains("SALMON") || n.contains("APPLE") || n.contains("BREAD") || n.contains("COOKIE") || n.contains("CAKE") || n.contains("PIE") || n.contains("STEW") || n.contains("SOUP") || n.contains("POTATO") || n.contains("CARROT") || n.contains("BERRIES") || n.contains("MELON_SLICE") || n.contains("ROTTEN_FLESH")) return Category.FOOD;
        if (n.contains("SPAWN_EGG") || n.contains("LEATHER") || n.contains("FEATHER") || n.contains("STRING") || n.contains("BONE") || n.contains("SLIME_BALL") || n.contains("GUNPOWDER") || n.contains("INK_SAC") || n.contains("PRISMARINE_SHARD")) return Category.MOB;
        if (n.contains("BRICK") || n.contains("GLASS") || n.contains("WOOL") || n.contains("CARPET") || n.contains("TERRACOTTA") || n.contains("CONCRETE") || n.contains("CANDLE") || n.contains("BANNER") || n.contains("PAINTING") || n.contains("ITEM_FRAME") || n.contains("FLOWER_POT") || n.contains("ARMOR_STAND")) return Category.DECOR;
        if (n.contains("NETHER_STAR") || n.contains("ELYTRA") || n.contains("TOTEM") || n.contains("DRAGON_EGG") || n.contains("BEACON") || n.contains("WITHER") || n.contains("HEART_OF_THE_SEA") || n.contains("CONDUIT") || n.contains("SHULKER")) return Category.RARE;
        if (n.contains("PLANKS") || n.contains("STAIRS") || n.contains("SLAB") || n.contains("WALL") || n.contains("BRICKS") || n.contains("BLOCK")) return Category.BUILDING;
        if (n.contains("PAPER") || n.contains("BOOK") || n.contains("STICK") || n.contains("STRING") || n.contains("LEAD") || n.contains("NAME_TAG") || n.contains("MAP") || n.contains("BUCKET") || n.contains("CHEST_MINECART") || n.contains("MINECART")) return Category.MATERIALS;
        return Category.MISC;
    }

    private boolean canTrade(Material m, boolean buying) {
        String path = "shop.prices." + m.name();
        if (!m.isItem() || m == Material.AIR || !getConfig().getBoolean(path + ".enabled", false)) return false;
        if (m == Material.NETHER_STAR) {
            if (!getConfig().getBoolean("nether-star.enabled", true)) return false;
            return getConfig().getBoolean("nether-star." + (buying ? "buy-enabled" : "sell-enabled"), true);
        }
        if (!getConfig().contains(path + "." + (buying ? "buy" : "sell")) && getConfig().getString("shop.unpriced-item-policy", "DENY").equalsIgnoreCase("DENY")) return false;
        if (buying && !getConfig().getBoolean("shop.allow-buy", true)) return false;
        if (!buying && !getConfig().getBoolean("shop.allow-sell", true)) return false;
        return price(m, buying) > 0;
    }
    private double price(Material m, boolean buying) {
        if (m == Material.NETHER_STAR) return getConfig().getDouble("nether-star." + (buying ? "buy-price" : "sell-price"), 0);
        String path = "shop.prices." + m.name() + "." + (buying ? "buy" : "sell");
        if (getConfig().contains(path)) return getConfig().getDouble(path, 0);
        if (getConfig().getString("shop.unpriced-item-policy", "DENY").equalsIgnoreCase("USE_DEFAULT")) return getConfig().getDouble("shop.default-" + (buying ? "buy" : "sell") + "-price", 0);
        return 0;
    }

    private static final class ShopView {
        Screen screen; Category category; int page;
        ShopView(Screen s, Category c, int p) { screen=s; category=c; page=p; }
    }
    private ItemStack icon(Material mat, String name, List<String> lore, String marker) {
        ItemStack it = new ItemStack(mat.isItem() && mat != Material.AIR ? mat : Material.BARRIER);
        ItemMeta meta = it.getItemMeta(); meta.setDisplayName(color(name)); if (lore != null) { List<String> l = new ArrayList<String>(); for(String x:lore) l.add(color(x)); meta.setLore(l); }
        meta.getPersistentDataContainer().set(menuKey, PersistentDataType.STRING, marker); it.setItemMeta(meta); return it;
    }
    private String catName(Category c) { return getConfig().getString("shop.categories." + c.name(), c.name()); }
    private void openHome(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&2&lRealm Shop"));
        Category[] cats = Category.values(); int slot=0;
        for (Category c : cats) {
            Material mat = categoryIcon(c);
            inv.setItem(slot++, icon(mat, "&a" + catName(c), Arrays.asList("&7برای مشاهده آیتم‌ها کلیک کنید"), "cat:" + c.name()));
        }
        inv.setItem(49, icon(Material.BARRIER, "&cبستن", null, "close"));
        p.openInventory(inv); views.put(p.getUniqueId(), new ShopView(Screen.HOME,null,0));
    }
    private Material categoryIcon(Category c) {
        switch(c) {
            case BUILDING:return Material.BRICKS; case STONE:return Material.DIAMOND; case WOOD:return Material.OAK_LOG;
            case EARTH:return Material.DIRT; case DECOR:return Material.PAINTING; case FARMING:return Material.WHEAT;
            case FOOD:return Material.COOKED_BEEF; case MOB:return Material.LEATHER; case MATERIALS:return Material.STICK;
            case REDSTONE:return Material.REDSTONE; case TOOLS:return Material.IRON_PICKAXE; case WEAPONS:return Material.IRON_SWORD;
            case ARMOR:return Material.IRON_CHESTPLATE; case POTIONS:return Material.POTION; case NETHER:return Material.NETHERRACK;
            case END:return Material.END_STONE; case OCEAN:return Material.PRISMARINE; case RARE:return Material.NETHER_STAR;
            default:return Material.CHEST;
        }
    }
    private void openCategory(Player p, Category c, int page) {
        List<Material> items = new ArrayList<Material>();
        for (Material m : Material.values()) if (m.isItem() && m != Material.AIR && categoryFor(m)==c && (canTrade(m,true)||canTrade(m,false))) items.add(m);
        Collections.sort(items, new Comparator<Material>() { public int compare(Material a, Material b){return a.name().compareTo(b.name());}});
        int per = Math.max(9, Math.min(45, getConfig().getInt("shop.items-per-page",45))); page=Math.max(0,page);
        int pages=Math.max(1,(items.size()+per-1)/per); if(page>=pages) page=pages-1;
        Inventory inv = Bukkit.createInventory(null, 54, color("&2" + catName(c) + " &7("+(page+1)+"/"+pages+")"));
        int start=page*per;
        for(int i=0;i<per && start+i<items.size();i++) {
            Material m=items.get(start+i); boolean buy=canTrade(m,true), sell=canTrade(m,false);
            List<String> lore=Arrays.asList("&7خرید: " + (buy ? "&a"+money(price(m,true)) : "&cغیرفعال"),
                    "&7فروش: " + (sell ? "&e"+money(price(m,false)) : "&cغیرفعال"),
                    "&8چپ: خرید ۱ | راست: فروش ۱","&8Shift: معامله ۱۶ عدد");
            inv.setItem(i, icon(m,"&f"+pretty(m.name()),lore,"item:"+m.name()));
        }
        inv.setItem(45, icon(Material.ARROW,"&eصفحه قبل",null,"prev"));
        inv.setItem(49, icon(Material.BARRIER,"&cبازگشت",null,"back"));
        inv.setItem(53, icon(Material.ARROW,"&eصفحه بعد",null,"next"));
        p.openInventory(inv); views.put(p.getUniqueId(),new ShopView(Screen.CATEGORY,c,page));
    }
    private String pretty(String n) { return n.toLowerCase(Locale.ROOT).replace('_',' ').replaceAll("\\b[a-z]", "$0"); }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p=(Player)e.getWhoClicked(); ShopView v=views.get(p.getUniqueId()); if(v==null) return;
        e.setCancelled(true);
        if(e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory()) return;
        ItemStack clicked=e.getCurrentItem(); if(clicked==null || !clicked.hasItemMeta()) return;
        String mark=clicked.getItemMeta().getPersistentDataContainer().get(menuKey,PersistentDataType.STRING); if(mark==null)return;
        if(mark.equals("close")) { p.closeInventory(); views.remove(p.getUniqueId()); return; }
        if(mark.equals("back")) { openHome(p); return; }
        if(mark.equals("prev")) { openCategory(p,v.category,v.page-1); return; }
        if(mark.equals("next")) { openCategory(p,v.category,v.page+1); return; }
        if(mark.startsWith("cat:")) { try { openCategory(p,Category.valueOf(mark.substring(4)),0); } catch(Exception ignored){} return; }
        if(mark.startsWith("item:")) {
            Material m; try {m=Material.valueOf(mark.substring(5));}catch(Exception ex){return;}
            boolean buy=e.getClick().isLeftClick(), sell=e.getClick().isRightClick();
            if(!buy&&!sell)return;
            int amount=e.isShiftClick()?16:1;
            trade(p,m,buy,amount);
            openCategory(p,v.category,v.page);
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { if(e.getWhoClicked() instanceof Player && views.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true); }
    @EventHandler public void onClose(InventoryCloseEvent e) { if(e.getPlayer() instanceof Player) views.remove(e.getPlayer().getUniqueId()); }

    private void trade(Player p, Material m, boolean buying, int amount) {
        if(!canTrade(m,buying)) { msg(p,"item-disabled"); return; }
        if(m==Material.NETHER_STAR) amount=Math.min(amount,Math.max(1,getConfig().getInt("nether-star.max-stack-per-transaction",1)));
        double unit=price(m,buying), total=unit*amount;
        if(!validMoney(total) || total<=0) { msg(p,"invalid-amount"); return; }
        UUID id=p.getUniqueId(); double bal=balance(id);
        if(buying) {
            if(bal+1e-9<total) { msg(p,"insufficient-funds"); return; }
            if(!hasRoom(p,m,amount)) { p.sendMessage(color("&cفضای خالی کافی در Inventory ندارید.")); return; }
            if(!setBalance(id,bal-total)) { msg(p,"invalid-amount"); return; }
            give(p,m,amount);
            msg(p,"transaction-success", map("amount",String.valueOf(amount),"item",pretty(m.name()),"total",money(total)));
        } else {
            int have=count(p,m); if(have<amount) { p.sendMessage(color("&cتعداد کافی از این آیتم ندارید.")); return; }
            if(!validMoney(bal+total)) { msg(p,"invalid-amount"); return; }
            remove(p,m,amount); setBalance(id,bal+total);
            msg(p,"sold",map("amount",String.valueOf(amount),"item",pretty(m.name()),"total",money(total)));
        }
    }
    private Map<String,String> map(String... a){Map<String,String> m=new HashMap<String,String>();for(int i=0;i+1<a.length;i+=2)m.put(a[i],a[i+1]);return m;}
    private int count(Player p, Material m) { int n=0; for(ItemStack it:p.getInventory().getStorageContents()) if(it!=null&&it.getType()==m)n+=it.getAmount(); return n; }
    private boolean hasRoom(Player p,Material m,int amount) {
        int max=m.getMaxStackSize(); int slots=0;
        for(ItemStack it:p.getInventory().getStorageContents()) if(it==null||it.getType()==Material.AIR)slots+=max; else if(it.getType()==m)slots+=Math.max(0,max-it.getAmount());
        return slots>=amount;
    }
    private void give(Player p,Material m,int amount) {
        while(amount>0){int n=Math.min(amount,m.getMaxStackSize());Map<Integer,ItemStack> left=p.getInventory().addItem(new ItemStack(m,n)); amount-=n; if(!left.isEmpty()){ for(ItemStack it:left.values()) p.getWorld().dropItemNaturally(p.getLocation(),it); break;}}
    }
    private void remove(Player p,Material m,int amount) {
        ItemStack[] contents=p.getInventory().getStorageContents();
        for(int i=0;i<contents.length&&amount>0;i++){ItemStack it=contents[i];if(it==null||it.getType()!=m)continue;int take=Math.min(amount,it.getAmount());it.setAmount(it.getAmount()-take);amount-=take;if(it.getAmount()<=0)contents[i]=null;}
        p.getInventory().setStorageContents(contents);
    }

    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String name=cmd.getName().toLowerCase(Locale.ROOT);
        if(name.equals("shop")) {
            if(!s.hasPermission("realmeconomy.shop")){msg(s,"no-permission");return true;}
            if(!(s instanceof Player)){msg(s,"player-only");return true;} openHome((Player)s); return true;
        }
        if(name.equals("money")) {
            if(!s.hasPermission("realmeconomy.money")){msg(s,"no-permission");return true;}
            if(a.length==0){if(!(s instanceof Player)){msg(s,"player-only");return true;}msg(s,"balance",map("amount",money(balance(((Player)s).getUniqueId()))));return true;}
            OfflinePlayer target=Bukkit.getOfflinePlayer(a[0]); if(!s.hasPermission("realmeconomy.admin.view")&&!s.getName().equalsIgnoreCase(a[0])){msg(s,"no-permission");return true;}
            msg(s,"other-balance",map("player",a[0],"amount",money(balance(target.getUniqueId()))));return true;
        }
        if(name.equals("pay")) {
            if(!s.hasPermission("realmeconomy.pay")){msg(s,"no-permission");return true;}
            if(!(s instanceof Player)){msg(s,"player-only");return true;}
            if(a.length!=2){s.sendMessage(color("&cاستفاده: /pay <player> <amount>"));return true;}
            Player from=(Player)s, to=Bukkit.getPlayerExact(a[0]); double amount=parse(a[1]);
            if(to==null||to.equals(from)){s.sendMessage(color("&cبازیکن مقصد باید آنلاین و متفاوت باشد."));return true;}
            if(!validTransaction(amount)||balance(from.getUniqueId())<amount||!validMoney(balance(to.getUniqueId())+amount)){msg(s,"invalid-amount");return true;}
            setBalance(from.getUniqueId(),balance(from.getUniqueId())-amount);setBalance(to.getUniqueId(),balance(to.getUniqueId())+amount);
            msg(from,"paid",map("player",to.getName(),"amount",money(amount)));msg(to,"received",map("player",from.getName(),"amount",money(amount)));return true;
        }
        if(name.equals("eco")) {
            if(a.length<2){s.sendMessage(color("&cاستفاده: /eco <give|take|set|view> <player> [amount]"));return true;}
            String action=a[0].toLowerCase(Locale.ROOT); String perm="realmeconomy.admin";
            if(action.equals("give"))perm="realmeconomy.admin.give";else if(action.equals("take"))perm="realmeconomy.admin.take";else if(action.equals("set"))perm="realmeconomy.admin.set";else if(action.equals("view"))perm="realmeconomy.admin.view";
            if(!s.hasPermission(perm)){msg(s,"no-permission");return true;}
            OfflinePlayer target=Bukkit.getOfflinePlayer(a[1]); double old=balance(target.getUniqueId());
            if(action.equals("view")){msg(s,"other-balance",map("player",a[1],"amount",money(old)));return true;}
            if(a.length<3){s.sendMessage(color("&cمبلغ را وارد کنید."));return true;} double amount=parse(a[2]);
            if(!validTransaction(amount)){msg(s,"invalid-amount");return true;}
            double next=action.equals("give")?old+amount:action.equals("take")?old-amount:action.equals("set")?amount:Double.NaN;
            if(!validMoney(next)||!setBalance(target.getUniqueId(),next)){msg(s,"invalid-amount");return true;}
            msg(s,"eco-success");return true;
        }
        return false;
    }
    private double parse(String s){try{return Double.parseDouble(s);}catch(Exception e){return Double.NaN;}}
    private boolean validTransaction(double v){return !Double.isNaN(v)&&!Double.isInfinite(v)&&v>=getConfig().getDouble("economy.minimum-transaction",0.01)&&v<=getConfig().getDouble("economy.max-transaction",1.0E9);}
}
